mapping = {}
i = 0
for x in range(9):
    for y in range(15):
        mapping[i] = 'testing' + str(x) + str(y) + '.png'
        i += 1

